n = eval(input('請輸入整數n:'))

for i in range(1,n+1):
    if n%i==0:
        print(i,end=' ')
