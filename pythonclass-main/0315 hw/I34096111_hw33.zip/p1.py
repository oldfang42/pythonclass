S =0

for i in range(1,5):
    S=S+ (4*i-2)**(9-2*i)
print(S)
