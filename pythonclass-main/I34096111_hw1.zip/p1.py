a= eval(input('請輸入正三角形的邊長a：'))

length = a*3
area = (a*a*(3**(1/2)))/4 

print(length)
print(area)
