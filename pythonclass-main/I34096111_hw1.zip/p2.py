a = eval(input('請輸入a: '))
b = eval(input('請輸入b: '))
c = eval(input('請輸入c: '))
print((a*(b+c))/2)

#print a(b+c)/2的值

x1= (-b+(b*b-4*a*c)**(1/2))/(2*a)
x2= (-b-(b*b-4*a*c)**(1/2))/(2*a)
print(x1)
print(x2)
