r= eval(input('請輸入一個正整數r: '))
area = r*r*3.14

print('面積= ',area)
