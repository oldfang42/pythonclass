x= eval(input('請輸入數字 x='))
ans = (x**3)+(5*x**2)+(5*x)+1
print('答案= ',ans)
